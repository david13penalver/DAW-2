package com.besport24.exercise;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DavidApplicationTests {

	@Test
	void contextLoads() {
	}

}
