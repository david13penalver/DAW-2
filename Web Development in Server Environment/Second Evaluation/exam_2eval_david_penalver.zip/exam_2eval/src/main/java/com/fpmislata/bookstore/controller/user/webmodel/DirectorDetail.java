package com.fpmislata.bookstore.controller.user.webmodel;

public record DirectorDetail(
        String name,
        String biography
) {
}
