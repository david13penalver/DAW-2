package com.fpmislata.bookstore.controller.user.webmodel;

public record FigureDetail(
        String name,
        String role,
        String description
) {
}
