package com.fpmislata.bookstore.controller.user.webmodel;

public record FigureWithRole(
        String name
) {
}
