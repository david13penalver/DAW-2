package com.fpmislata.bookstore.controller.user.webmodel;

public record GameCollection(
        String title,
        String link
) {
}
