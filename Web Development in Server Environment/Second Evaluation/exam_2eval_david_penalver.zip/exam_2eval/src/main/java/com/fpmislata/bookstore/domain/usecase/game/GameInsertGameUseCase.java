package com.fpmislata.bookstore.domain.usecase.game;

import com.fpmislata.bookstore.domain.model.Game;

public interface GameInsertGameUseCase {
    void execute(Game game);
}
