package com.fpmislata.bookstore.domain.service;

import com.fpmislata.bookstore.domain.model.Book;
import com.fpmislata.bookstore.domain.model.OrderDetail;

import java.util.Optional;

public interface OrderDetailService {
    //OrderDetail addBook(id, order_id, book.getId(), quantity, price);
}
