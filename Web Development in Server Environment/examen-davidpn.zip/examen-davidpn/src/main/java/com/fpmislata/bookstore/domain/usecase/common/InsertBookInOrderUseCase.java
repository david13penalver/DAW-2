package com.fpmislata.bookstore.domain.usecase.common;

import com.fpmislata.bookstore.domain.model.Order;

import java.math.BigDecimal;

public interface InsertBookInOrderUseCase {
    //Order execute(Long id, Long order_id, Long idBook,int quantity, BigDecimal price);
}
