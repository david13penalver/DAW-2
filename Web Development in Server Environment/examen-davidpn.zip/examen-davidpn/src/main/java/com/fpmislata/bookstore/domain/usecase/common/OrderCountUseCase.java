package com.fpmislata.bookstore.domain.usecase.common;

public interface OrderCountUseCase {
    int execute();
}
